package com.example.q1;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {

    private EditText etTaskName, etDueDate;
    private Spinner spinnerPriority;
    private Button btnSave;
    private ListView lvTasks;

    private DatabaseHelper dbHelper;
    private TaskAdapter adapter;
    private List<Task> taskList;
    private Task editingTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTaskName = findViewById(R.id.etTaskName);
        etDueDate = findViewById(R.id.etDueDate);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        btnSave = findViewById(R.id.btnSave);
        lvTasks = findViewById(R.id.lvTasks);

        // Prevent keyboard from showing up on due date field
        etDueDate.setFocusable(false);
        etDueDate.setOnClickListener(v -> showDatePicker());

        dbHelper = new DatabaseHelper(this);
        taskList = dbHelper.getAllTasks();
        adapter = new TaskAdapter(this, taskList, this);
        lvTasks.setAdapter(adapter);

        btnSave.setOnClickListener(v -> saveTask());
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, monthOfYear, dayOfMonth) -> {
                    String date = year1 + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth);
                    etDueDate.setText(date);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void saveTask() {
        String name = etTaskName.getText().toString().trim();
        String dueDate = etDueDate.getText().toString().trim();
        String priority = spinnerPriority.getSelectedItem().toString();

        if (name.isEmpty() || dueDate.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (editingTask == null) {
            Task newTask = new Task(name, dueDate, priority);
            dbHelper.addTask(newTask);
            Toast.makeText(this, "Task Saved", Toast.LENGTH_SHORT).show();
        } else {
            editingTask.setName(name);
            editingTask.setDueDate(dueDate);
            editingTask.setPriority(priority);
            dbHelper.updateTask(editingTask);
            Toast.makeText(this, "Task Updated", Toast.LENGTH_SHORT).show();
            editingTask = null;
            btnSave.setText("Save Task");
        }

        clearFields();
        refreshTaskList();
    }

    private void clearFields() {
        etTaskName.setText("");
        etDueDate.setText("");
        spinnerPriority.setSelection(0);
        etTaskName.clearFocus();
    }

    private void refreshTaskList() {
        taskList = dbHelper.getAllTasks();
        adapter.updateTasks(taskList);
    }

    @Override
    public void onEdit(Task task) {
        editingTask = task;
        etTaskName.setText(task.getName());
        etDueDate.setText(task.getDueDate());
        
        for (int i = 0; i < spinnerPriority.getCount(); i++) {
            if (spinnerPriority.getItemAtPosition(i).toString().equalsIgnoreCase(task.getPriority())) {
                spinnerPriority.setSelection(i);
                break;
            }
        }
        
        btnSave.setText("Update Task");
        etTaskName.requestFocus();
    }

    @Override
    public void onDelete(Task task) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete Task")
                .setMessage("Are you sure you want to delete this task?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    dbHelper.deleteTask(task.getId());
                    refreshTaskList();
                    Toast.makeText(MainActivity.this, "Task Deleted", Toast.LENGTH_SHORT).show();
                    if (editingTask != null && editingTask.getId() == task.getId()) {
                        editingTask = null;
                        btnSave.setText("Save Task");
                        clearFields();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}
